import UIKit
import PlaygroundSupport

fileprivate extension CGFloat {
    static var outerCircleRatio: CGFloat = 0.8
    static var innerCircleRatio: CGFloat = 0.55
    static var inProgressRatio: CGFloat = 0.58
}

fileprivate extension Double {
    static var animationDuration = 1.0
    static var inProgressPeriod = 2.0
}

enum ButtonStatus {
    case connected
    case connecting
    case disconnected
}

class ButtonView: UIView {
    
    private let buttonLayer = CALayer()
    private var state = ButtonStatus.disconnected
    
    private lazy var innerCircle: CAShapeLayer = {
        let l = CAShapeLayer()
        
        l.path = Utils.pathForCircleInRect(rect: buttonLayer.bounds, scaled: CGFloat.innerCircleRatio)
        l.fillColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        l.strokeColor = #colorLiteral(red: 0.1215686275, green: 0.1294117647, blue: 0.1411764706, alpha: 1)
        l.lineWidth = 3
        
        l.shadowRadius = 15
        l.shadowColor = #colorLiteral(red: 0.1215686275, green: 0.1294117647, blue: 0.1411764706, alpha: 1)
        l.shadowOffset = CGSize(width: 15, height: 10)
        l.shadowOpacity = 0.3
        
        return l
    }()
    
    private lazy var outerCircle: CAShapeLayer = {
        let sl = CAShapeLayer()
        
        sl.path = Utils.pathForCircleInRect(rect: buttonLayer.bounds, scaled: CGFloat.outerCircleRatio)
        sl.fillColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        sl.opacity = 0.3
        
        return sl
    }()
    
    private lazy var badgeLayer: CAGradientLayer = {
        let l = CAGradientLayer()
    
        l.colors = [#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)].map {$0.cgColor}
        l.frame = layer.bounds
        l.mask = createBadgeMaskLayer()
        
        return l
    }()
    
    private lazy var inProgressLayer: CAGradientLayer = {
        let l = CAGradientLayer()
        
        l.colors = [#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1), #colorLiteral(red: 0.6963732839, green: 0.7060831189, blue: 0.7145655751, alpha: 1)].map {$0.cgColor}
        l.locations = [0, 0.7]
        l.frame = CGRect(centre: buttonLayer.bounds.centre, size: buttonLayer.bounds.size.rescale(CGFloat.inProgressRatio))
        l.isHidden = true
        
        let mask = CAShapeLayer()
        mask.path = UIBezierPath(ovalIn: l.bounds).cgPath
        l.mask = mask
        
        return l
    }()
    
    private lazy var greenBackgroundLayer: CAShapeLayer = {
        let l = CAShapeLayer()
        
        l.path = Utils.pathForCircleInRect(rect: buttonLayer.frame, scaled: CGFloat.innerCircleRatio)
        l.fillColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        l.opacity = 0.6
        l.mask = createBadgeMaskLayer()
        
        return l
    }()
    
    private func createBadgeMaskLayer() -> CAShapeLayer {
        let mask = CAShapeLayer()
        
        mask.path = UIBezierPath.badgePath.cgPath
        let scale = layer.bounds.width / UIBezierPath.badgePath.bounds.width
        mask.transform = CATransform3DMakeScale(scale, scale, 1)
        
        return mask
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureLayers()
        setupTapGesture()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func configureLayers() {
        backgroundColor = .white
        
        buttonLayer.frame = bounds.largestContainedSquare
        buttonLayer.addSublayer(outerCircle)
        buttonLayer.addSublayer(inProgressLayer)
        buttonLayer.addSublayer(innerCircle)
        
        layer.addSublayer(badgeLayer)
        layer.addSublayer(greenBackgroundLayer)
        layer.addSublayer(buttonLayer)
    }
    
    fileprivate func setupTapGesture() {
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleTap)))
    }
    
    @objc fileprivate func handleTap() {
        switch state {
        case .disconnected:
            state = .connecting
            inProgressLayer.isHidden = false
            
            let animation = CABasicAnimation(keyPath: "transform.rotation.z")
            animation.fromValue = 0
            animation.toValue = 2 * Double.pi
            animation.duration = Double.animationDuration
            animation.repeatCount = .greatestFiniteMagnitude
            inProgressLayer.add(animation, forKey: "progressAnimation")
            
        case .connecting:
            state = .connected
            inProgressLayer.isHidden = true
            inProgressLayer.removeAnimation(forKey: "progressAnimation")
            
            // animate green layer
            let path = Utils.pathForCircleThatContains(rect: layer.frame)
            
            let animation = CABasicAnimation(keyPath: "path")
            animation.fromValue = greenBackgroundLayer.path
            animation.toValue = path
            animation.duration = 1.0
            animation.timingFunction = CAMediaTimingFunction(name: .easeOut)
            
            greenBackgroundLayer.add(animation, forKey: "expandAnimation")
            greenBackgroundLayer.path = path
            
        case .connected:
            state = .disconnected
            
            // animate green layer
            let path = Utils.pathForCircleInRect(rect: buttonLayer.frame, scaled: CGFloat.innerCircleRatio)
            
            let animation = CABasicAnimation(keyPath: "path")
            animation.fromValue = greenBackgroundLayer.path
            animation.toValue = path
            animation.duration = 1.0
            animation.timingFunction = CAMediaTimingFunction(name: .easeOut)
            
            greenBackgroundLayer.add(animation, forKey: "expandAnimation")
            greenBackgroundLayer.path = path
        }
        
        print(state)
    }
}

let aspectRatio = UIBezierPath.badgePath.bounds.width / UIBezierPath.badgePath.bounds.height
let button = ButtonView(frame: CGRect(x: 0, y: 0, width: 300, height: 300 / aspectRatio))
PlaygroundPage.current.liveView = button
